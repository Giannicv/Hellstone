using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChanger : MonoBehaviour
{
    // Opci�n A: m�todo sin par�metros (f�cil)
    public void GoToMenuOptions()
    {
        SceneManager.LoadScene("MenuOptions");
    }

    // Opci�n B: m�todo que recibe el nombre de la escena (�til si quer�s usar varios botones con el mismo componente)
    public void GoToByName(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    // Opci�n C: m�todo por �ndice (si prefer�s usar el �ndice en Build Settings)
    public void GoToByIndex(int index)
    {
        SceneManager.LoadScene(index);
    }
}
