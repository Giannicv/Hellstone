using UnityEngine;

public class ExitGame : MonoBehaviour
{
    // M�todo que se llamar� cuando el bot�n sea presionado
    public void QuitGame()
    {
#if UNITY_EDITOR
        // Si estamos en el editor, dejamos el juego "en pausa" pero no lo cerramos
        UnityEditor.EditorApplication.isPlaying = false;
#else
        // Si estamos en el build del juego, cerramos la aplicaci�n
        Application.Quit();
#endif
    }
}
